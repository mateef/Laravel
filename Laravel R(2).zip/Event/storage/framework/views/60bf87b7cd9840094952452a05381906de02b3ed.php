<?php header('Content-Type: charset=utf-8');?>


<?php $__env->startSection('content'); ?>
	<div class="off-canvas-content" data-off-canvas-content>
          <div class="title-bar hide-for-large">
            <div class="title-bar-left">
              <button class="menu-icon" type="button" data-open="fomenu"></button>
              <span class="title-bar-title">Laravel rendezvény</span>
            </div>
          </div>


		 <?php if(Session::has('message')): ?>
		  <div class="callout success" onClick="$(this).fadeOut()">
		  <?php echo e(Session::get('message')); ?>

			<button class="close-button" type="button">&times;</button>
			</div>
			<?php endif; ?>

          <div class="callout primary">
            <div class="row column">
              <h1>Rendezvények</h1>
              <p class="lead">Nézz szét az események között és foglalj jegyet az előadásokra! ☻</p>
            </div>
          </div>
          <div class="row small-up-2 medium-up-3 large-up-4">

			<?php
			foreach($events as $event) {

			?>
            <div class="column">
              <a href="/event/show/<?php echo $event->id ?>">
				<img class="thumbnail" src="boritokepek/<?php echo $event->cover_image ?>">
			  </a>
              <h5><?php echo $event->name ?></h5>
			  <p><?php echo $event->description ?><p>
			  <p>Időpont: <?php echo $event->date ?><p>
			  <p>Ár: <?php echo $event->price ?> Ft<p>
			  <p>Fellépő: <?php echo $event->lineup ?><p>
			  <p>Helyszín: <?php echo $event->location ?><p>

            </div>          
			<?php
			}
			?>


          </div>          
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Event\resources\views/event/index.blade.php ENDPATH**/ ?>