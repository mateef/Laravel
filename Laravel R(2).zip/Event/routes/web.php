<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EventController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\TicketsController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::group(['middleware' => 'web'], function() {

Route::get('/', [EventController::class,'index']);

Route::resource('event', EventController::class);
Route::get('/event/show/{id}', [EventController::class,'show']);

Auth::routes();

Route::get('/home', [EventController::class,'index']);


Route::get('/logout', [LoginController::class,'logout']);

Route::get('new-ticket', 'TicketsController@create');

Route::post('new-ticket', 'TicketsController@store');

Route::get('my_tickets', 'TicketsController@userTickets');

Route::get('tickets/{ticket_id}', 'TicketsController@show');

});