<?php

namespace App\Http\Controllers;
use DB;
use Auth;
use Illuminate\Http\Request;

class EventController extends Controller
{
    public function index() {
		$events = DB::table('events')->get();
		return view('event/index', compact('events'));
	}

	public function create() {
		if (!Auth::check()) {
			return \Redirect::route('event.index') -> with('message', 'Csak bejelentkezett felhasználó hozhat létre eseményt.');
		}
		return view('event/create');
	}

	public function store(Request $request) {
		$nev = $request->input('nev');
		$datum = $request->input('datum');
		$leiras = $request->input('leiras');
		$jegyar = $request->input('jegyar');
		$fellepo = $request->input('fellepo');
		$helyszin = $request->input('helyszin');
		$boritokep = $request->file('boritokep');
		$tulajdonos = 1;

		if ($boritokep)	{
			//die('Rendben');
			$fajlnev = $boritokep->getClientOriginalName();
			$boritokep->move(public_path('boritokepek'),$fajlnev);
		}
		else{
			$fajlnev = 'nincskep.jpg';
		}

		DB::table('events')->insert(
			[
				'name' => $nev,
				'description' => $leiras,
				'date' => $datum,
				'price' => $jegyar,
				'lineup' => $fellepo,
				'location' => $helyszin,
				'owner_id' => $tulajdonos,
				'cover_image' => $fajlnev
				
			]
		);

			return \Redirect::route('event.index') -> with('message', 'Esemény sikeresen rögzítve.');

	}

	public function show($id) {
		die('Esemény azonosítója: '.$id);
	}
}
