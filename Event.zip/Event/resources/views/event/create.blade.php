<?php header('Content-Type: charset=utf-8');?>
@extends('layouts.main')

@section('content')
	<div class="off-canvas-content" data-off-canvas-content>
          <div class="title-bar hide-for-large">
            <div class="title-bar-left">
              <button class="menu-icon" type="button" data-open="fomenu"></button>
              <span class="title-bar-title">Laravel rendezvény</span>
            </div>
          </div>
          <div class="callout primary">
            <div class="row column">
              <h1>Új esemény felvétele</h1>
              <p class="lead">Készíts új eseményt.</p>
            </div>
          </div>

          <div class="row small-up-2 medium-up-3 large-up-4">
            <div class="margo">
			{{ Form::open(['action' => 'App\Http\Controllers\EventController@store', 'enctype' => 'multipart/form-data']) }}
				  {!! Form::label('nev','Név') !!}
                  {!! Form::text('nev', $value=null, $attributes=['placeholder'=>'Esemény neve', 'name'=>'nev']) !!}

				  {!! Form::label('datum','Dátum') !!}
                  {!! Form::date('datum', $value=null, $attributes=['placeholder'=>'Esemény időpontja', 'name'=>'datum']) !!}

                  {!! Form::label('leiras','Leírás') !!}
                  {!! Form::text('leiras', $value=null, $attributes=['placeholder'=>'Esemény leírása', 'name'=>'leiras']) !!}

				  {!! Form::label('jegyar','Jegyár') !!}
                  {!! Form::text('jegyar', $value=null, $attributes=['placeholder'=>'Esemény ára', 'name'=>'jegyar']) !!}

				  {!! Form::label('fellepo','Fellépő') !!}
                  {!! Form::text('fellepo', $value=null, $attributes=['placeholder'=>'Fellépő neve', 'name'=>'fellepo']) !!}

				  {!! Form::label('helyszin','Helyszín') !!}
                  {!! Form::text('helyszin', $value=null, $attributes=['placeholder'=>'Esemény helyszíne', 'name'=>'helyszin']) !!}

                  {!! Form::label('boritokep','Borítókép') !!}
                  {!! Form::file('boritokep') !!}

                  {!! Form::submit('Létrehozás', $attributes=['class'=>'button']) !!}

			{{ Form::close() }}
				</div>
          </div>
                  
        @stop

