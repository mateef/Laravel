<?php header('Content-Type: charset=utf-8');?>


<?php $__env->startSection('content'); ?>
	<div class="off-canvas-content" data-off-canvas-content>
          <div class="title-bar hide-for-large">
            <div class="title-bar-left">
              <button class="menu-icon" type="button" data-open="fomenu"></button>
              <span class="title-bar-title">Laravel rendezvény</span>
            </div>
          </div>
          <div class="callout primary">
            <div class="row column">
              <h1>Új esemény felvétele</h1>
              <p class="lead">Készíts új eseményt.</p>
            </div>
          </div>

          <div class="row small-up-2 medium-up-3 large-up-4">
            <div class="margo">
			<?php echo e(Form::open(['action' => 'App\Http\Controllers\EventController@store', 'enctype' => 'multipart/form-data'])); ?>

				  <?php echo Form::label('nev','Név'); ?>

                  <?php echo Form::text('nev', $value=null, $attributes=['placeholder'=>'Esemény neve', 'name'=>'nev']); ?>


				  <?php echo Form::label('datum','Dátum'); ?>

                  <?php echo Form::date('datum', $value=null, $attributes=['placeholder'=>'Esemény időpontja', 'name'=>'datum']); ?>


                  <?php echo Form::label('leiras','Leírás'); ?>

                  <?php echo Form::text('leiras', $value=null, $attributes=['placeholder'=>'Esemény leírása', 'name'=>'leiras']); ?>


				  <?php echo Form::label('jegyar','Jegyár'); ?>

                  <?php echo Form::text('jegyar', $value=null, $attributes=['placeholder'=>'Esemény ára', 'name'=>'jegyar']); ?>


				  <?php echo Form::label('fellepo','Fellépő'); ?>

                  <?php echo Form::text('fellepo', $value=null, $attributes=['placeholder'=>'Fellépő neve', 'name'=>'fellepo']); ?>


				  <?php echo Form::label('helyszin','Helyszín'); ?>

                  <?php echo Form::text('helyszin', $value=null, $attributes=['placeholder'=>'Esemény helyszíne', 'name'=>'helyszin']); ?>


                  <?php echo Form::label('boritokep','Borítókép'); ?>

                  <?php echo Form::file('boritokep'); ?>


                  <?php echo Form::submit('Létrehozás', $attributes=['class'=>'button']); ?>


			<?php echo e(Form::close()); ?>

				</div>
          </div>
                  
        <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Event\resources\views/event/create.blade.php ENDPATH**/ ?>